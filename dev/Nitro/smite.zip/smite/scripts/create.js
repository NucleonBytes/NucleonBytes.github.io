var Nitro = new NitroCore();
Nitro.import("jquery");

function gocreate(){
	var vname = document.getElementById("aname").value;
	var desc = document.getElementById("afolder").value;
	storInfo(vname,desc);
}

function storInfo(appname,appfolder){
	storage.store('appname',appname.toString());
	storage.store('appfolder',appfolder.toString());
	
	alert(storage.fetch('appfolder'));
	window.location.href = 'studio.html';
}