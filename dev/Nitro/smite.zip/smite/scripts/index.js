var Nitro = new NitroCore();
Nitro.import("prefixfree");
Nitro.import("jquery");

app.setminsize("width",750);
app.setminsize("height",560);