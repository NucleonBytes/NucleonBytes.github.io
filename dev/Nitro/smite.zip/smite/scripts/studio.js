var Nitro = new NitroCore();
Nitro.import("jquery");
ace.require("ace/ext/language_tools");
			var editor = ace.edit("editor");
			editor.setTheme("ace/theme/monokai");
			editor.getSession().setTabSize(4);
			editor.getSession().setUseSoftTabs(true);
			editor.getSession().setUseWrapMode(true);
			editor.getSession().setMode("ace/mode/html");
			editor.setOptions({
	        	enableBasicAutocompletion: true,
	        	enableSnippets: true,
	        	enableLiveAutocompletion: true
	    	});

startPollingSave(".ace_text-input");

var xname = storage.fetch('appname');
var xfolder = storage.fetch('appfolder');

var currentFile = "\\index.html";

newproject();

function newproject(){
	openFile(xfolder + "\\index.html");
	addToSideBar("\\index.html");
	addToSideBar("\\" +xname+".jnx");
	addToSideBar("\\style.css");
}

function loadFile(filex){
	var folderpath = storage.fetch('appfolder');
	openFile(folderpath + "\\" + filex);
}

function setAceLanguage(lang){
	editor.getSession().setMode("ace/mode/"+lang)
}

function openFile(filepath){
	if (fs.checkFile(filepath) == false){
		fs.createFile(filepath); //Creates a new file if file does not exist
	}
	document.getElementsByClassName('spacedtext')[0].innerHTML = filepath.substr(filepath.lastIndexOf('\\')+1);
	if (filepath.substr(filepath.lastIndexOf('.')+1).toLowerCase() == "jnx"){
		stopPollingSave(".ace_text-input");
		setAceLanguage("json");
		editor.setValue(fs.readFile(filepath),0);
		startPollingSave(".ace_text-input");
	}
	else{
		stopPollingSave(".ace_text-input");
		setAceLanguage(filepath.substr(filepath.lastIndexOf('.')+1).toLowerCase());
		editor.setValue(fs.readFile(filepath),0);
		startPollingSave(".ace_text-input");
	}
	currentFile = "\\" + filepath.substr(filepath.lastIndexOf('\\')+1);
}

function addToSideBar(filex){
	var mydiv = document.getElementsByClassName("sidebar")[0];
	var aTag = document.createElement('li');
	aTag.setAttribute('onclick', "loadFile('"+filex+"')");
	aTag.innerHTML = filex;
	mydiv.appendChild(aTag);
	
	//<li onclick="loadFile('pab.html')">pab.html</li>
}

var oldleftVal
var handlex
function startPollingSave(elemSelector)
{
    handlex = window.setInterval(function(){

        var element = $(elemSelector);
        if (element.css("left") != oldleftVal) {
			saveDoc();
        }
		oldleftVal = element.css("left");

    }, 1500);
}

editor.on("change", function(){
	stopPollingSave(".ace_text-input");
	startPollingSave(".ace_text-input");
});

function stopPollingSave(elemSelector){
	window.clearInterval(handlex);
}

function saveDoc(){
	fs.writeFile(xfolder + currentFile,editor.getValue(),false);
}

function createManifest(){
	
}

window.onbeforeunload = function(){	
	stopPollingSave(".ace_text-input");
}